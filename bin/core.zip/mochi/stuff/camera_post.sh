#!/sbin/sh
camera_post() {
	echo -e "\n" >> /vendor/etc/init/hw/init.target.rc
	echo -e "on post-fs-data" >> /vendor/etc/init/hw/init.target.rc
	echo -e "\n    mkdir /data/misc/camera/   0777 camera camera" >> /vendor/etc/init/hw/init.target.rc
	echo -e "\n    mkdir /data/vendor/camera/ 0777 camera camera" >> /vendor/etc/init/hw/init.target.rc
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && camera_post
