#!/sbin/sh
camera_post() {
	echo -e "\non post-fs-data" >> /vendor/etc/init.target.rc
	echo -e "\nmkdir /data/misc/camera/ 0777 camera camera" >> /vendor/etc/init.target.rc
	echo -e "\nmkdir /data/vendor/camera/ 0777 camera camera" >> /vendor/etc/init.target.rc
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && camera_post
