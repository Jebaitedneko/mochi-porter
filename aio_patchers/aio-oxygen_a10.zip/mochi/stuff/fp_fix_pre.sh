#!/sbin/sh
fp_fix_pre() {
	fp_binary=` find /vendor/bin/hw -type f -iname "*biometrics\.fingerprint*" `
	mv "$fp_binary" "${fp_binary}_backup"
	echo "$fp_binary" > /vendor/bin/hw/fp_binary_name.txt
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && fp_fix_pre
