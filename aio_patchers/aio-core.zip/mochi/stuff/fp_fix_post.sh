#!/sbin/sh
fp_fix_post() {
	fp_binary=` find /vendor/bin/hw -type f -iname "*biometrics\.fingerprint*" `
	fp_service=` find /vendor/etc/init -type f -iname "*biometrics\.fingerprint*" `
	cat /tmp/stuff/biometrics.rc >> $fp_service
	chcon -t hal_fingerprint_default_exec $fp_binary
	chcon -t hal_fingerprint_default_exec $fp_service
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && fp_fix_post
