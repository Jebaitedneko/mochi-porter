#!/sbin/sh
overlayfix() {
	overlayapk=`find /vendor/overlay -type f -iname "*framework*"`
	sed -i "s|4100|4000|g" $overlayapk
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && overlayfix
