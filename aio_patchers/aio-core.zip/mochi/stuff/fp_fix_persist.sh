#!/sbin/sh
find /persist/data -type f -maxdepth 1 -delete
