#!/sbin/sh
fp_fix_pre() {
	fp_binary=` find /vendor/bin/hw -type f -iname "*biometrics\.fingerprint*" `
	fp_service=` find /vendor/etc/init -type f -iname "*biometrics\.fingerprint*" `
	rm "$fp_binary"
	rm "$fp_service"
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && fp_fix_pre
