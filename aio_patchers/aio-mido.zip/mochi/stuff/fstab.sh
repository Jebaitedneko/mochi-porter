#!/sbin/sh
main() {
    cat /tmp/stuff/init.qcom.rc >> /vendor/etc/init/hw/init.qcom.rc
    cat /tmp/stuff/init.target.rc >> /vendor/etc/init/hw/init.target.rc
    sed -i '/^#/d' /vendor/etc/fstab.qcom
    sed -i 's/\/cust/\/vendor/g' /vendor/etc/fstab.qcom
    awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
    rm /vendor/etc/fstab.qcom
    mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
    echo "qemu.hw.mainkeys=0" >> /vendor/build.prop
    echo "persist.camera.video.CDS=off" >> /vendor/build.prop
    echo "persist.camera.CDS=off" >> /vendor/build.prop
    vendor_decrypt() {
        sed -i 's/,encryptable=[a-z]*[,]/\,/g' /vendor/etc/fstab.qcom
        sed -i 's/,encryptable=[a-z]*//g' /vendor/etc/fstab.qcom
        sed -i 's/encryptable=[a-z]*//g' /vendor/etc/fstab.qcom
        awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
        rm /vendor/etc/fstab.qcom
        mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
    }
    [ ! -e "/dev/block/dm-0" ] && vendor_decrypt
    echo -e "\n#Patched by MOCHI" >> /vendor/etc/fstab.qcom
}

fp_fix() {
fp_binary=` find /vendor/bin/hw -type f -iname "*biometrics\.fingerprint*" `
rm $fp_binary
mv /vendor/bin/hw/android.hardware.biometrics.fingerprint@2.1-service.xiaomi_mido $fp_binary
fp_service=` find /vendor/etc/init -type f -iname "*biometrics\.fingerprint*" `
cat /tmp/stuff/biometrics.rc >> $fp_service
chmod 0755 /vendor/bin/move_fingerprint_data.sh
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && main

fp_fix
