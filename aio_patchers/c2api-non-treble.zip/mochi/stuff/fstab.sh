#!/sbin/sh
main() {
    sed -i '/^#/d' /system/vendor/etc/fstab.qcom
    sed -i 's/\/cust/\/system/vendor/g' /system/vendor/etc/fstab.qcom
    awk 'BEGIN{RS="";ORS="\n"}1' /system/vendor/etc/fstab.qcom > /system/vendor/etc/fstab.qcom.new
    rm /system/vendor/etc/fstab.qcom
    mv /system/vendor/etc/fstab.qcom.new /system/vendor/etc/fstab.qcom
    echo "qemu.hw.mainkeys=0" >> /system/vendor/build.prop
    echo "persist.camera.video.CDS=off" >> /system/vendor/build.prop
    echo "persist.camera.CDS=off" >> /system/vendor/build.prop
    echo "persist.camera.HAL3.enabled=1" >> /system/vendor/build.prop
    vendor_decrypt() {
        sed -i 's/,encryptable=[a-z]*[,]/\,/g' /system/vendor/etc/fstab.qcom
        sed -i 's/,encryptable=[a-z]*//g' /system/vendor/etc/fstab.qcom
        sed -i 's/encryptable=[a-z]*//g' /system/vendor/etc/fstab.qcom
        awk 'BEGIN{RS="";ORS="\n"}1' /system/vendor/etc/fstab.qcom > /system/vendor/etc/fstab.qcom.new
        rm /system/vendor/etc/fstab.qcom
        mv /system/vendor/etc/fstab.qcom.new /system/vendor/etc/fstab.qcom
    }
    [ ! -e "/dev/block/dm-0" ] && vendor_decrypt
    echo -e "\n#Patched by MOCHI" >> /system/vendor/etc/fstab.qcom
}

res=`grep -q "#Patched by MOCHI" "/system/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && main
