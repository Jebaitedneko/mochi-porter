#!/sbin/sh
main() {
    cat /tmp/stuff/init.qcom.rc >> /vendor/etc/init/hw/init.qcom.rc
    cat /tmp/stuff/init.target.rc >> /vendor/etc/init/hw/init.target.rc
    sed -i '/^#/d' /vendor/etc/fstab.qcom
    sed -i 's/\/cust/\/vendor/g' /vendor/etc/fstab.qcom
    awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
    rm /vendor/etc/fstab.qcom
    mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
    echo "qemu.hw.mainkeys=0" >> /vendor/build.prop
    echo "persist.camera.video.CDS=off" >> /vendor/build.prop
    echo "persist.camera.CDS=off" >> /vendor/build.prop
    vendor_decrypt() {
        sed -i 's/,encryptable=[a-z]*[,]/\,/g' /vendor/etc/fstab.qcom
        sed -i 's/,encryptable=[a-z]*//g' /vendor/etc/fstab.qcom
        sed -i 's/encryptable=[a-z]*//g' /vendor/etc/fstab.qcom
        awk 'BEGIN{RS="";ORS="\n"}1' /vendor/etc/fstab.qcom > /vendor/etc/fstab.qcom.new
        rm /vendor/etc/fstab.qcom
        mv /vendor/etc/fstab.qcom.new /vendor/etc/fstab.qcom
    }
    [ ! -e "/dev/block/dm-0" ] && vendor_decrypt
    echo -e "\n#Patched by MOCHI" >> /vendor/etc/fstab.qcom
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && main
