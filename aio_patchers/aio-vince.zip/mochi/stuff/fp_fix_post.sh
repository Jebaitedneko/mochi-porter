#!/sbin/sh
fp_fix_post() {
	mv "/vendor/bin/hw/android.hardware.biometrics.fingerprint@2.1-service.xiaomi_mido" ` cat /vendor/bin/hw/fp_binary_name.txt `
	fp_service=` find /vendor/etc/init -type f -iname "*biometrics\.fingerprint*" `
	cat /tmp/stuff/biometrics.rc >> $fp_service
	chmod 0755 /vendor/bin/move_fingerprint_data.sh
}

res=`grep -q "#Patched by MOCHI" "/vendor/etc/fstab.qcom" ; echo $?`
[ $res -eq 1 ] && fp_fix_post
